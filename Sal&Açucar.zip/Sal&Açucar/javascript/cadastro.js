const form = document.querySelector('#form');

form.addEventListener('submit', function (e) {
    e.preventDefault();

    const fields = [
        {
            id: 'name',
            label: 'Nome',
            validation: nameIsValid,
        },
        {
            id: 'name_mom',
            label: 'Nome da Mãe',
            validation: nameIsValid,
        },
        {
            id:'birthdate',
            label:'Data de Nascimento',
            validation: dateIsValid,
        },
        {
            id:'email',
            label:'E-mail',
            validation: emailIsValid,
        },
        {
            id: 'cpf',
            label: 'CPF',
            validation: cpfIsValid,
        },
        {
            id: 'login',
            label: 'Login',
            validation: loginIsValid,
        },
        {
            id: 'cep',
            label: 'CEP',
            validation: cepIsValid,
        },
        {
            id: 'cidade',
            label: 'Cidade',
            validation: cidadeIsValid,
        },
        {
            id: 'bairro',
            label: 'Bairro',
            validation: bairroIsValid,
        },
        {
            id: 'rua',
            label: 'Rua',
            validation: ruaIsValid,
        },

        {
            id:'password',
            label:'Senha',
            validation: passwordIsSecure,
        },
        {
            id:'confirm_password',
            label:'Confirmar Senha',
            validation: passwordMatch
        },
        {
            id: 'cel',
            label: 'Telefone celular',
            validation: celIsValid,
        },
        {
            id: 'fixo',
            label: 'Telefone fixo',
            validation: fixoIsValid,
        },

    ];

    const erroIcon = '<i class="fa-solid fa-circle-exclamation"></i>';
    let formHasError = false;

    fields.forEach(function (field) {
        const input = document.getElementById(field.id);
        const inputBox = input.closest('.input_box');
        const inputValue = input.value.trim();
        const erroSpan = inputBox.querySelector('.erro');

        if (erroSpan) erroSpan.innerHTML = '';
        inputBox.classList.remove('invalid', 'valid');

        const validationResult = field.validation(inputValue);

        if (!validationResult.isValid) {
            if (erroSpan) {
                erroSpan.innerHTML = `${erroIcon} ${validationResult.erroMessage}`;
            }
            inputBox.classList.add('invalid');
            formHasError = true;
        } else {
            inputBox.classList.add('valid');
        }
    });

    if (!formHasError) {
        console.log('Formulário válido. Você pode enviar agora.');
        // Aqui você pode prosseguir com o envio
    }

    const genders = document.getElementsByName('gender'); // <-- corrigido
    const radioContainer = document.querySelector('.radio-container');
    const genderErrorSpan = radioContainer.querySelector('.erro');

    const selectedGender = [...genders].find(input => input.checked);

   radioContainer.classList.add('invalid');
   radioContainer.classList.remove('valid');
   genderErrorSpan.innerHTML = `${erroIcon} Selecione um gênero`;

    if (selectedGender) {
      radioContainer.classList.add('valid');
      radioContainer.classList.remove('invalid');
      genderErrorSpan.innerHTML = '';
     return;
}





});




function isEmpty(value) {
    return value === '';
}

function nameIsValid(value) {
    const validator = {
        isValid: true,
        erroMessage: null
    };

    const min = 15;
    const max = 80;

    if (isEmpty(value)) {
        validator.isValid = false;
        validator.erroMessage = 'O campo é obrigatório';
        return validator;
    }

    if (value.length < min) {
        validator.isValid = false;
        validator.erroMessage = `O campo deve ter no mínimo ${min} caracteres.`;
        return validator;
    }

    if (value.length > max) {
        validator.isValid = false;
        validator.erroMessage = `O campo deve ter no máximo ${max} caracteres.`;
        return validator;
    }

    const regex = /^[A-Za-zÀ-ÿ\s]+$/;
    if (!regex.test(value)) {
        validator.isValid = false;
        validator.erroMessage = 'O campo deve conter apenas letras e espaços.';
        return validator;
    }

    return validator;
}

  
   
function dateIsValid(value){
    const validator = {
        isValid: true,
        erroMessage: null
    };

    if (isEmpty(value)) {
        validator.isValid = false;
        validator.erroMessage = 'O campo é obrigatório';
        return validator;
    }

    const year = new Date(value).getFullYear();

    if (year < 1920 || year > new Date().getFullYear()) {
        validator.isValid = false;
        validator.erroMessage = 'Data inválida';
        return validator;
    }

    return validator;
}

function emailIsValid(value){
    const validator = {
        isValid: true,
        erroMessage: null
    };

    if (isEmpty(value)) {
        validator.isValid = false;
        validator.erroMessage = 'O campo é obrigatório';
        return validator;
    }
     const regex  = new RegExp("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$");
     if(!regex.test(value)){
        
            validator.isValid = false;
            validator.erroMessage = 'O e-mail precisa ser válido';
            return validator;
        
     }
     return validator;
}
function celIsValid(value) {
    const validator = {
        isValid: true,
        erroMessage: null
    }

    if (isEmpty(value)) {
        validator.isValid = false;
        validator.erroMessage = 'O campo é obrigatório';
        return validator;
    }

    const cleaned = value.trim();
    const phoneRegex = /^\(\+\d{1,3}\) \d{2} \d{5}-\d{3,4}$/;

    if (!phoneRegex.test(cleaned)) {
        validator.isValid = false;
        validator.erroMessage = 'Telefone inválido';
        return validator;
    }

    return validator;
}


function fixoIsValid(value) {
    const validator = {
        isValid: true,
        erroMessage: null
    }
    if (isEmpty(value)) {
        validator.isValid = false;
        validator.erroMessage = 'O campo é obrigatório';
        return validator;
    }

    const fixoRegex = /^\(\+\d{1,3}\) \d{2} \d{5}-\d{3,4}$/;

    if (!fixoRegex.test(value)) {
        validator.isValid = false;
        validator.erroMessage = 'Telefone inválido';
        return validator;
    }

    return validator;
}


function cepIsValid(value) {
    const validator = {
        isValid: true,
        erroMessage: null
    }

    if (isEmpty(value)) {
        validator.isValid = false;
        validator.erroMessage = 'O campo é obrigatório';
        return validator;
    }

    const cleaned = value.trim();
    const cepRegex = /^\d{5}-\d{3}$/;

    if (!cepRegex.test(cleaned)) {
        validator.isValid = false;
        validator.erroMessage = 'CEP inválido';
        return validator;
    }

    return validator;
}

function cidadeIsValid(value) {
    const validator = {
        isValid: true,
        erroMessage: null
    }

    if (isEmpty(value)) {
        validator.isValid = false;
        validator.erroMessage = 'O campo é obrigatório';
        return validator;
    }

    return validator;
}

function bairroIsValid(value) {
    const validator = {
        isValid: true,
        erroMessage: null
    }

    if (isEmpty(value)) {
        validator.isValid = false;
        validator.erroMessage = 'O campo é obrigatório';
        return validator;
    }

    return validator;
}

function ruaIsValid(value) {
    const validator = {
        isValid: true,
        erroMessage: null
    }

    if (isEmpty(value)) {
        validator.isValid = false;
        validator.erroMessage = 'O campo é obrigatório';
        return validator;
    }

    return validator;
}

function cpfIsValid(value) {
    const validator = {
        isValid: true,
        erroMessage: null
    }

    if (isEmpty(value)) {
        validator.isValid = false;
        validator.erroMessage = 'O campo é obrigatório';
        return validator;
    }

    const cleaned = value.replace(/\D/g, ''); // remove tudo que não for número

    if (cleaned.length !== 11 || /^(\d)\1{10}$/.test(cleaned)) {
        validator.isValid = false;
        validator.erroMessage = 'CPF inválido.';
        return validator;
    }

    // Validação do primeiro dígito verificador
    let sum = 0;
    for (let i = 0; i < 9; i++) {
        sum += parseInt(cleaned[i]) * (10 - i);
    }
    let firstDigit = 11 - (sum % 11);
    if (firstDigit >= 10) firstDigit = 0;
    if (firstDigit !== parseInt(cleaned[9])) {
        validator.isValid = false;
        validator.erroMessage = 'CPF inválido.';
        return validator;
    }

    // Validação do segundo dígito verificador
    sum = 0;
    for (let i = 0; i < 10; i++) {
        sum += parseInt(cleaned[i]) * (11 - i);
    }
    let secondDigit = 11 - (sum % 11);
    if (secondDigit >= 10) secondDigit = 0;
    if (secondDigit !== parseInt(cleaned[10])) {
        validator.isValid = false;
        validator.erroMessage = 'CPF inválido.';
        return validator;
    }

    return validator;
}




function loginIsValid(value) {
    const validator = {
        isValid: true,
        erroMessage: null
    }
    if (isEmpty(value)) {
        validator.isValid = false;
        validator.erroMessage = 'O campo é obrigatório';
        return validator;
    }

    const min = 6;

    if (value.length !== min) {
        validator.isValid = false;
        validator.erroMessage = `O campo deve ter ${min} caracteres.`;
        return validator;
    }

    return validator;
}


function passwordIsSecure(value){
    const validator = {
        isValid: true,
        erroMessage: null
    };

    if (isEmpty(value)) {
        validator.isValid = false;
        validator.erroMessage = 'O campo é obrigatório';
        return validator;
    }

    if (value.length < 8) {
        validator.isValid = false;
        validator.erroMessage = 'A senha deve ter no mínimo 8 caracteres.';
        return validator;
    }

    return validator;
}

function passwordMatch(value) {
    const validator = {
        isValid: true,
        erroMessage: null
    };

    const passwordInput = document.getElementById('password');

    if (!passwordInput) {
        validator.isValid = false;
        validator.erroMessage = 'Campo de senha não encontrado';
        return validator;
    }

    const passwordValue = passwordInput.value;

    if (isEmpty(value)) {
        validator.isValid = false;
        validator.erroMessage = 'O campo é obrigatório';
        return validator;
    }

    if (value !== passwordValue) {
        validator.isValid = false;
        validator.erroMessage = 'Senhas não condizem';
        return validator;
    }

    return validator;
}



//mascaras
$('#cpf').mask('000.000.000-00');
$('#cep').mask('00000-000');
$('#cel').mask('(+00) 00 00000-0000');
$('#fixo').mask('(+00) 00 00000-0000');

//achar as informações do endereço pelo cep
$('#cep').blur(function () {
    var vl = this.value;

    $.get('https://viacep.com.br/ws/'+vl+'/json', function (dados) {

        $('#cidade').val(dados.localidade);
        $('#bairro').val(dados.bairro);
        $('#rua').val(dados.logradouro);
    });
});


//para fazer o olhinho da senha
const passwordIcons = document.querySelectorAll('.password-icon');

passwordIcons.forEach(icon =>{
    icon.addEventListener('click', function() {
        const input = this.parentElement.querySelector('.form-control');
        input.type = input.type === 'password' ? 'text' : 'password';
        this.classList.toggle('fa-eye');
    })  
})